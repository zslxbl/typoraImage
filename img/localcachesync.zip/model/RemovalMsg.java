package com.zslxbl.springdemo.localcachesync.model;

import com.google.common.cache.RemovalCause;
import lombok.Data;

import java.io.Serializable;

/**
 * @Author: sp-0094
 * @Description:
 * @Version: 1.0.0
 * @Date: 2022/05/15 15:13
 * @Modifede By: 15:13
 */

@Data
public class RemovalMsg<K, V> implements Serializable {

    private static final long serialVersionUID = -965080742899628150L;

    private K k;
    private V v;
    private String name;
    private RemovalCause cause;
}
