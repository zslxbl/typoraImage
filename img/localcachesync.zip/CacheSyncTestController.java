package com.zslxbl.springdemo.localcachesync;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Author: sp-0094
 * @Description:
 * @Version: 1.0.0
 * @Date: 2022/05/15 15:23
 * @Modifede By: 15:23
 */

@RestController
public class CacheSyncTestController {
    @Autowired
    private LocalCacheServiceA localCacheServiceA;
    @Autowired
    private LocalCacheServiceB localCacheServiceB;

    @GetMapping("/testA")
    public Object getById(Long id) {
        return localCacheServiceA.getById(id);
    }

    @GetMapping("/testB")
    public Object getById2(Long id) {
        return localCacheServiceB.getById(id);
    }

}
