package com.zslxbl.springdemo.localcachesync.component;

import com.google.common.cache.LoadingCache;
import com.zslxbl.springdemo.localcachesync.ListenerPlan;
import com.zslxbl.springdemo.localcachesync.annotations.CacheSyncSupporter;
import lombok.SneakyThrows;
import org.apache.dubbo.remoting.zookeeper.ZookeeperClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

import java.lang.reflect.Field;


/**
 * @Author: sp-0094
 * @Description:
 * @Version: 1.0.0
 * @Date: 2022/05/15 16:21
 * @Modifede By: 16:21
 */

@Component
public class InitSyncConfig implements ApplicationListener<ContextRefreshedEvent>, ApplicationContextAware {
    final Logger logger = LoggerFactory.getLogger(InitSyncConfig.class);

    private ApplicationContext applicationContext;

    @Autowired
    private ListenerPlan listenerPlan;

    @SneakyThrows
    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {
        String[] beanDefinitionNames = applicationContext.getBeanDefinitionNames();
        for (String beanDefinitionName : beanDefinitionNames) {
            Object bean = applicationContext.getBean(beanDefinitionName);
            Class<?> clazz = bean.getClass();
            Field[] fields = clazz.getDeclaredFields();
            for (Field field : fields) {
                field.setAccessible(true);
                if (field.isAnnotationPresent(CacheSyncSupporter.class)) {
                    CacheSyncSupporter annotation = field.getAnnotation(CacheSyncSupporter.class);
                    String value = annotation.value();
                    LoadingCache loadingCache = (LoadingCache)field.get(bean);
                    listenerPlan.putCache(value, loadingCache);
                }

            }
        }
        listenerPlan.afterPropertiesSet();
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }
}
