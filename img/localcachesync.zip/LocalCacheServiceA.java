package com.zslxbl.springdemo.localcachesync;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.zslxbl.springdemo.dao.UserDao;
import com.zslxbl.springdemo.entry.User;
import com.zslxbl.springdemo.localcachesync.annotations.CacheSyncSupporter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.concurrent.TimeUnit;

/**
 * @Author: sp-0094
 * @Description:
 * @Version: 1.0.0
 * @Date: 2022/05/15 13:48
 * @Modifede By: 13:48
 */

@Slf4j
@Service
public class LocalCacheServiceA {
    @Resource
    private UserDao userDao;

    @CacheSyncSupporter("LocalCacheServiceA#loadingCache")
    private LoadingCache<Long, User> loadingCache;

    @PostConstruct
    private void init() {
        CacheLoader<Long, User> cacheLoader = new CacheLoader<Long, User>() {
            @Override
            public User load(Long key) throws Exception {
                log.info("LocalCacheServiceA load key:{}", key);
                return userDao.getById(key);
            }
        };

        loadingCache = CacheBuilder.newBuilder()
                .expireAfterWrite(10, TimeUnit.SECONDS)
                .maximumSize(100)
                .removalListener(RemovalListenerCommon.of("LocalCacheServiceA#loadingCache"))
                .build(cacheLoader);

    }

    public User getById(Long id) {

        return loadingCache.getUnchecked(id);
    }


}
