package com.zslxbl.springdemo.localcachesync.pubsub;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

/**
 * @Author: sp-0094
 * @Description:
 * @Version: 1.0.0
 * @Date: 2022/05/15 14:25
 * @Modifede By: 14:25
 */

public class SubThread extends Thread {
    private final JedisPool jedisPool;

    private final Subscriber subscriber = new Subscriber();

    private String channel;

    public SubThread(JedisPool jedisPool, String channel) {

        super("SubThread");

        this.jedisPool = jedisPool;
        this.channel = channel;

    }

    @Override

    public void run() {

        System.out.println(String.format("subscribe redis, channel %s, thread will be blocked", channel));

        Jedis jedis = null;

        try {

            jedis = jedisPool.getResource();

            jedis.subscribe(subscriber, channel);

        } catch (Exception e) {

            System.out.println(String.format("subsrcibe channel error, %s", e));

        } finally {

            if (jedis != null) {

                jedis.close();

            }

        }

    }

}
