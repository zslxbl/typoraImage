package com.zslxbl.springdemo.localcachesync;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

/**
 * @Author: sp-0094
 * @Description:
 * @Version: 1.0.0
 * @Date: 2022/05/15 15:01
 * @Modifede By: 15:01
 */

@Configuration
public class CacheConfig {

    @Bean
    public JedisPool jedisPool() {

        return new JedisPool(new JedisPoolConfig(), "localhost", 6379);
    }
}
