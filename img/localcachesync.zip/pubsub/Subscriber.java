package com.zslxbl.springdemo.localcachesync.pubsub;

import com.alibaba.fastjson.JSONObject;
import com.google.common.cache.LoadingCache;
import com.zslxbl.springdemo.localcachesync.ListenerPlan;
import com.zslxbl.springdemo.localcachesync.model.RemovalMsg;
import redis.clients.jedis.JedisPubSub;

/**
 * @Author: sp-0094
 * @Description:
 * @Version: 1.0.0
 * @Date: 2022/05/15 14:23
 * @Modifede By: 14:23
 */
public class Subscriber extends JedisPubSub {

    @Override
    public void onMessage(String channel, String message) {
        System.out.println(String.format("receive redis published message, channel %s, message %s", channel, message));
        RemovalMsg msg = JSONObject.parseObject(message, RemovalMsg.class);

        LoadingCache loadingCache = ListenerPlan.getByName(channel);

        loadingCache.invalidate(msg.getK());
    }

    @Override
    public void onSubscribe(String channel, int subscribedChannels) {
        System.out.println(String.format("subscribe redis channel success, channel %s, subscribedChannels %d", channel, subscribedChannels));

    }
}
