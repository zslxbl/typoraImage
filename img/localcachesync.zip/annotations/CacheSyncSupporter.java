package com.zslxbl.springdemo.localcachesync.annotations;

import java.lang.annotation.*;

/**
 * @Author: sp-0094
 * @Description:
 * @Version: 1.0.0
 * @Date: 2022/05/15 14:51
 * @Modifede By: 14:51
 */

@Documented
@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
public @interface CacheSyncSupporter {

    String value();
}
