package com.zslxbl.springdemo.localcachesync;

import com.google.common.cache.RemovalListener;
import com.google.common.cache.RemovalNotification;
import com.zslxbl.springdemo.localcachesync.model.RemovalMsg;
import com.zslxbl.springdemo.localcachesync.pubsub.Publisher;
import lombok.Getter;
import lombok.Setter;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

/**
 * @Author: sp-0094
 * @Description:
 * @Version: 1.0.0
 * @Date: 2022/05/15 13:54
 * @Modifede By: 13:54
 */


@Setter
@Getter
public class RemovalListenerCommon implements RemovalListener {
    private String name;

    public static RemovalListenerCommon of(String name) {
        return new RemovalListenerCommon(name);
    }


    private RemovalListenerCommon(String name) {
        this.name = name;
    }

    @Override
    public void onRemoval(RemovalNotification notification) {
        Object key = notification.getKey();
        Object value = notification.getValue();
        System.out.println("RemovalListenerCommon onRemoval, key:" + key + ", value:" + value);

        // FIXME: 2022/5/15 发送redis订阅
        JedisPool localhost = new JedisPool(new JedisPoolConfig(), "localhost", 6379);

        RemovalMsg msg = new RemovalMsg();
        msg.setK(key);
        msg.setV(value);
        msg.setName(name);
        msg.setCause(notification.getCause());


        Publisher publisher = new Publisher(localhost);
        publisher.start(msg);

    }
}
