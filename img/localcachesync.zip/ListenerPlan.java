package com.zslxbl.springdemo.localcachesync;

import com.google.common.cache.LoadingCache;
import com.zslxbl.springdemo.localcachesync.pubsub.SubThread;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;
import redis.clients.jedis.JedisPool;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @Author: sp-0094
 * @Description:
 * @Version: 1.0.0
 * @Date: 2022/05/15 14:45
 * @Modifede By: 14:45
 */

@Slf4j
@Component
public class ListenerPlan {
    @Autowired
    private JedisPool jedisPool;

    private static Map<String, LoadingCache> loadingCacheMap = new ConcurrentHashMap<>();

    public void putCache(String name, LoadingCache loadingCache) {
        if (loadingCacheMap.containsKey(name)) {
            throw new RuntimeException("LoadingCache name already exist, name:" + name);
        }
        loadingCacheMap.putIfAbsent(name, loadingCache);
    }

    public void afterPropertiesSet() throws Exception {
        for (Map.Entry<String, LoadingCache> entry : loadingCacheMap.entrySet()) {
            SubThread subThread = new SubThread(jedisPool, entry.getKey());
            subThread.start();
        }
    }

    public static LoadingCache getByName(String key) {
        return loadingCacheMap.get(key);
    }
}
