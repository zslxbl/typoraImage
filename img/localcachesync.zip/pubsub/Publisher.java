package com.zslxbl.springdemo.localcachesync.pubsub;

import com.alibaba.fastjson.JSONObject;
import com.zslxbl.springdemo.localcachesync.model.RemovalMsg;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

/**
 * @Author: sp-0094
 * @Description:
 * @Version: 1.0.0
 * @Date: 2022/05/15 14:28
 * @Modifede By: 14:28
 */
public class Publisher {

    private final JedisPool jedisPool;

    public Publisher(JedisPool jedisPool) {

        this.jedisPool = jedisPool;

    }

    public void start(RemovalMsg msg) {
        Jedis jedis = jedisPool.getResource();


        String line = null;

        try {
            System.out.println("publish start, name:" + msg.getName());
            jedis.publish(msg.getName(), JSONObject.toJSONString(msg));

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}

